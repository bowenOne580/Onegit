#include<iostream>
using namespace std;
int main(){
	int n;
	cin>>n;
	int a,b;
	a=5*n;
	b=3*n+11;
	if (a>b){
		cout<<"Luogu";
	} 
	else{
		cout<<"Local";
	}
	return 0;
}

