#include<iostream>
using namespace std;
int main(){
	int a;
	cin>>a;
	int n;
	cin>>n;
	cout<<a*n; 
	return 0;
}

