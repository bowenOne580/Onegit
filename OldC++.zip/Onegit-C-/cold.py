while True:
    print(1)