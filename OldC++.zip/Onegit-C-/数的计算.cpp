#include<iostream>
using namespace std;
int main(){
	int n,num=1;
	cin>>n;
	for (int i=0;i<=n/2)
	{
		if (i!=0) num++;
	}
	return 0;
}

