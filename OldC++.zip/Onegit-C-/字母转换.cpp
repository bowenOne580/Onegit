#include<iostream>
using namespace std;
int main(){
	char a;
	cin>>a;
	a-='a';
	a+='A';
	cout<<a;
	return 0;
}

