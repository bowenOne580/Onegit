
//基于字符串p型编码编写

#include<iostream>
#include<cstring>
using namespace std;
int main(){
    char a[1005]={};
    cin>>a;
    for (int i=0;i<strlen(a);i++)
    {
        if (a[i]>='a' && a[i]<='z')
        {
            a[i]-=32;
        }
    }
    int num = 0; //记录每一次的数量
    for (int i=0;i<strlen(a);i++)
    {
        num++;
        if (a[i]!=a[i-1]&&i>0)
        {
            cout<<"("<<a[i-1]<<","<<num-1<<")";
            num = 1;
        }
    }
    cout<<"("<<a[strlen(a)-1]<<","<<num<<")";
    return 0;
}
