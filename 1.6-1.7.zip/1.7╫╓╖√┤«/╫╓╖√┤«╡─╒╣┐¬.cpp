#include<iostream>
#include<cstring>
using namespace std;
char a[105]= {};
int p1,p2,p3,i;
int main() {
	cin >>p1>>p2>>p3;
	cin>>a;
	for (i=0; i<strlen(a); i++) {
		if (a[i]=='-' && i!=0) {
			if (a[i-1]<a[i+1]-1 && a[i+1]!='-' && a[i-1]!='-') {
				if ((a[i-1]>='0' && a[i-1]<='9' && a[i+1]>='A' && a[i+1]<='z'))
				{
					cout<<"-";
				}
				else{
				if (p1==1) {
					if (p3==1) {
						for (int j=a[i-1]+1; j<a[i+1]; j++) {
							if ((a[i-1]+1)>='A' && a[i-1]<='Z') {
								for (int p=0; p<p2; p++) {
									cout<<char(j+32);
								}
							} else {
								for (int p=0; p<p2; p++) {
									cout<<char(j);
								}
							}
						}
					} else {
						for (int j=a[i+1]-1; j>a[i-1]; j--) {
							if ((a[i-1]+1)>='A' && a[i-1]<='Z') {
								for (int p=0; p<p2; p++) {
									cout<<char(j+32);
								}
							} else {
								for (int p=0; p<p2; p++) {
									cout<<char(j);
								}
							}
						}
					}
				} else if (p1==2) {
					if (p3==1) {
						for (int j=a[i-1]+1; j<a[i+1]; j++) {
							if ((a[i-1]+1)>='a' && a[i-1]<='z') {
								for (int p=0; p<p2; p++) {
									cout<<char(j-32);
								}
							} else {
								for (int p=0; p<p2; p++) {
									cout<<char(j);
								}
							}
						}
					} else {
						for (int j=a[i+1]-1; j>a[i-1]; j--) {
							if ((a[i-1]+1)>='a' && a[i-1]<='z') {
								for (int p=0; p<p2; p++) {
									cout<<char(j-32);
								}
							} else {
								for (int p=0; p<p2; p++) {
									cout<<char(j);
								}
							}
						}
					}
				} else if (p1==3) {
					for (int j=a[i-1]+1; j<a[i+1]; j++) {
						for (int p=0; p<p2; p++) {
							cout<<"*";
						}
					}
				}
			}
			}
			else if (a[i-1]==a[i+1]-1) continue;
            else
            {
                cout<<"-";
            }
		}
        else cout<<a[i];
	}
	return 0;
}