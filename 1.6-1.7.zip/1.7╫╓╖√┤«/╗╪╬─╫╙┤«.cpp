#include<iostream>
#include<cstring>
using namespace std;
int main() {
	char a[505]= {},b[505]= {};
	cin>>a;
	int now=-2,biggest=-1;
	while(now<=biggest) {
		if (now==-2) {
			now=1;
		}
		for (int i=0; i<strlen(a); i++) {
			int j=1;
			while(a[i+j]==a[i-j] && i-j>=0 && i+j<strlen(a)) {
				b[j]=a[i-j];
				if (j*2+1 == now) {
					for (int p=j; p>=1; p--) {
						cout<<b[p];
					}
					cout<<a[i];
					for (int p=1; p<=j; p++) {
						cout<<b[p];
					}
					cout<<endl;
				}
				j++;
				if (j*2+1>biggest) {
					biggest=j*2+1;
				}
			}
			if (a[i] == a[i-1]) {
				if (now==1) cout<<a[i]<<a[i-1]<<endl;
				int j=1;
				while(a[i+j]==a[i-j-1] && i-j-1>=0 && i+j<strlen(a)) {
					b[j]=a[i-1-j];
					if ((j+1)*2 == now) {
						for (int p=j; p>=1; p--) {
							cout<<b[p];
						}
						cout<<a[i]<<a[i-1];
						for (int p=1; p<=j; p++) {
							cout<<b[p];
						}
						cout<<endl;
					}
					j++;
					if ((j+1)*2>biggest) {
						biggest=(j+1)*2;
					}
				}
			}
		}
		now++;
	}
	return 0;
}
