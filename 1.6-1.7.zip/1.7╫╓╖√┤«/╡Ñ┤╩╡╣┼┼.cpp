// 基于旧版有错的单词翻转编写
#include<iostream>
#include<cstring>
using namespace std;
char a[505]={};
int main(){
    cin.getline(a,500);
    int start=strlen(a)-1;
    int i,j;
    for (i=strlen(a)-1;i>=0;i--){
        if (a[i]==' ' || a[i] == '\r'){
            for (j=i+1;j<=start;j++){
                cout<<a[j];
            }
            cout<<" ";
            start = i-1;
        }
    }
    for (j=i+1;j<=start;j++){
                cout<<a[j];
            }
    return 0;
}
