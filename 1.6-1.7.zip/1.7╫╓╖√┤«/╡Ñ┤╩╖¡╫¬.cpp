#include<iostream>
#include<cstring>
using namespace std;
char a[505]={};
int main(){
    cin.getline(a,500);
    int start=0;
    int i,j;
    a[strlen(a)] = ' ';
    for (i=0;i<strlen(a);i++){
        if (a[i]==' '){
            for (j=i-1;j>=start;j--){
                cout<<a[j];
            }
            cout<<" ";
            start = i+1;
        }
    }
    return 0;
}
