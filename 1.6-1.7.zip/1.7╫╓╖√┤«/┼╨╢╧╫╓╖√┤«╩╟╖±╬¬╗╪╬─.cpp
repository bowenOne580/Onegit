#include<iostream>
#include<cstring>
using namespace std;
int main(){
    char a[105]={};
    cin>>a;
    bool aa=true;
    for (int i=0;i<strlen(a)-1;i++){
        if (a[i]!=a[strlen(a)-1-i])
        {
            aa=false;
        }
    }
    if (aa){
        cout<<"yes";
    }
    else{
        cout<<"no";
    }
    return 0;
}
