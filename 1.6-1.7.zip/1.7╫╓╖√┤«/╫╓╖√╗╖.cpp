#include<iostream>
#include<cstring>
using namespace std;
int main(){
    char a[1500]={},b[1500]={};
    cin>>a>>b;
    int lena=strlen(a),lenb=strlen(b);
    int len=1;
    int maxlen=-1;
    for (int i=0;i<lena;i++){
        a[lena+i]=a[i];
    }
    for (int i=0;i<lenb;i++){
        b[lenb+i]=b[i];
    }
    for (int i=0;i<strlen(a);i++){
        for (int j=0;j<strlen(b);j++){
            if (a[i]==b[j]){
                // Till here, all right.
                int p=i+1,q=j+1;
                while(a[p]==b[q] &&p<strlen(a)&&q<strlen(b))
                {
                    len++;
                    p++;
                    q++;
                }
                if (len>maxlen && len<=lena){
                    maxlen=len;
                }
                len=1;
            }
        }
    }
    cout<<maxlen;
    return 0;
}
