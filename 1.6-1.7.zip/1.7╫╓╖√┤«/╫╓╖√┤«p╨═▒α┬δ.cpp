#include<iostream>
#include<cstring>
using namespace std;
int main(){
    char a[1005]={};
    cin>>a;
    int num = 0; //记录每一次的数量
    for (int i=0;i<strlen(a);i++)
    {
        num++;
        if (a[i]!=a[i-1]&&i>0)
        {
            cout<<num-1<<a[i-1];
            num = 1;
        }
    }
    cout<<num<<a[strlen(a)-1];
    return 0;
}
