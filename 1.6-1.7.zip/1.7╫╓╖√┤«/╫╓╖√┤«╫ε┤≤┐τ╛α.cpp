#include<iostream>
using namespace std;
int main(){
    string s,s1,s2,s3;
    int l1,l2;
    cin>>s;
    l1=s.find(',');
    l2=s.rfind(',');
    s1=s.substr(0,l1);
    s2=s.substr(l1+1,l2-l1-1);
    s3=s.substr(l2+1,s.length()-l2-1);
    l1=s1.find(s2);
    l2=s1.rfind(s3);
    if (l1+s2.length()<=l2) cout<<l2-l1-s2.length();
    else cout<<"-1";
    return 0;
}
