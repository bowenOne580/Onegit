#include<iostream>
using namespace std;
int main(){
    int a[205],b[205];
    // 用高精度加法（含进位，去除前导0）
    
    return 0;
}
