#include<iostream>
#include<cstring>
using namespace std;
int i=1;
int main(){
    int n,a,fac[50000],ans [ 50000 ]={1 , 1};;
    cin >> n;
    for ( i =1; i <=n; i ++){
        for (int j =1 ; j <=ans [ 0 ]; j ++){
            ans [ j ] = ans [ j ]*i+fac[ j ];
            fac [ j ] = 0 ;
        if ( ans [ j ] >= 10){
            fac [ j +1 ] += ans [ j ] / 10;
            ans [ j ] %= 10;
            if ( j ==ans [ 0]) ++ans [ 0 ];
            }
        }
    }
    return 0;
}
