#include<iostream>
using namespace std;
int main(){
    int a[105][105],n,ifA[105],ifB[105],aa=0,bb=0;
    cin>>n;
    for (int i=0;i<n;i++){
        for (int j=0;j<n;j++){
            cin>>a[i][j];
        }
    }  
    for (int i=0;i<n;i++){
        for (int j=0;j<n;j++){
            ifA[i]+=a[i][j];
            ifB[j]+=a[i][j];
        }
    }
    // Till here, OK.
    for (int i=0;i<n;i++){
        for (int j=0;j<n;j++){
            if (ifA[i]%2!=0 || ifB[j]%2!=0){
                bb++;
            }
            if (ifA[i]%2!=0 && ifB[j]%2!=0){
                aa++;
            }
        }
    }
    if (bb==0){
        cout<<"OK";
    }
    else{
         if (aa==1){
            for (int i=0;i<n;i++){
                for (int j=0;j<n;j++){
                    if (ifA[i]%2!=0 && ifB[j]%2!=0){
                        cout<<i+1<<" "<<j+1;
                    }
                }
            }
        }
        else{
            cout<<"Corrupt";
        }
    }
    return 0;
}
