#include<iostream>
using namespace std;
int main(){
	int a[105],b[105],n,a1,b1,wina = 0,winb = 0;
	cin>>n>>a1>>b1;
	for (int i=1;i<=a1;i++)
	{
		cin>>a[i];
	}
	for (int i=1;i<=b1;i++)
	{
		cin>>b[i];
	}
    // 进行比赛
	for (int i=1;i<=n;i++)
	{
		if (i>a1)
		{
			a[i] = a[i-a1];
		}
		if (i>b1)
		{
			b[i] = b[i-b1];
		}
		if (a[i] > b[i])
		{
			if (a[i] == 5 && b[i] == 0)
			{
				wina++;
			}
			else
			{
				winb++;
			}
		}
		if (a[i] < b[i])
		{
			if (a[i] == 0 && b[i] == 5)
			{
				winb++;
			}
			else
			{
				wina++;
			}
		}
	}
	if (wina > winb)
	{
		cout<<"A";
	}
	else if (wina == winb)
	{
		cout<<"draw";
	}
	else
	{
		cout<<"B";
	}
	return 0;
}